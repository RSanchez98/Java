package com.company;

public class FichaAlumno
{
    public String nombre;
    public int edad;
    public double calificacion;

}
